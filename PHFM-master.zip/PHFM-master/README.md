A website for the Phoenix Hill Farmers' Market. I tried to enhance their current site by implementing better UI by using responsive design for a mobile friendly site.
To view website, run index.html
